'use strict' 

exports.OTP_VERIFIED = 0;
exports.OTP_UNVERIFIED = 1;
exports.OTP_VALID = 2;
exports.OTP_EXPIRED = 3;
exports.OTP_INVALID = 4;
//export const OTP_UNVERIFIED = 1;
